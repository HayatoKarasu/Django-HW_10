from django.contrib import admin
from django.urls import path

from humans.views import index, get_prof, view_human, add_humans

urlpatterns = [
    path('', index, name='Home'),
    path('prof/<int:profession_id>', get_prof, name='Prof'),
    path('humans/<int:human_id>', view_human, name='View_human'),
    path('humans/add_humans', add_humans, name='Add_humans'),
]

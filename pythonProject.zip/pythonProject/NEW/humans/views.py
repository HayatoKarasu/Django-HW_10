from django.shortcuts import render, get_object_or_404, redirect
from .models import Human, Prof
from .forms import HumanForm


def index(request):
    humans = Human.objects.all()
    context = {
        'humans': humans,
        'title': 'Список людей',
    }
    return render(request, 'humans/index.html', context=context)


def get_prof(request, profession_id):
    humans = Human.objects.filter(profession_id=profession_id)
    profes = Prof.objects.get(pk=profession_id)
    context = {
        'humans': humans,
        'profes': profes
    }
    return render(request, 'humans/prof.html', context=context)


def view_human(request, human_id):
    #human_item = Human.objects.get(pk=human_id)
    human_item = get_object_or_404(Human, pk=human_id)
    context = {
        'human_item': human_item,
    }
    return render(request, 'humans/view_human.html', context=context)


def add_humans(request):
    if request.method == 'POST':
        form = HumanForm(request.POST)
        if form.is_valid():
            #humans = Human.objects.create(**form.cleaned_data)
            humans = form.save()
            return redirect(humans)
    else:
        form = HumanForm()
    return render(request, 'humans/add_humans.html', {'form': form})
